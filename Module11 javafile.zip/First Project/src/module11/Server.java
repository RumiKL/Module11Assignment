package module11;

import java.io.*;
import java.net.*;
import java.util.Date;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.scene.Scene;
import javafx.scene.control.ScrollPane;
import javafx.scene.control.TextArea;
import javafx.stage.Stage;

public class Server extends Application {

  private static final double number = 0;


public void start(Stage primaryStage) {
   
    TextArea ta = new TextArea();

 
    Scene scene = new Scene(new ScrollPane(ta), 450, 200);
    primaryStage.setTitle("Server"); 
    primaryStage.setScene(scene); 
    primaryStage.show(); 
    
    new Thread( () -> {
      try {
      
        @SuppressWarnings("resource")
		ServerSocket serverSocket = new ServerSocket(8000);
        Platform.runLater(() ->
          ta.appendText("Server started at " + new Date() + '\n'));
  
     
        Socket socket = serverSocket.accept();
  
     
        DataInputStream inputFromClient = new DataInputStream(
          socket.getInputStream());
        @SuppressWarnings("unused")
		DataOutputStream outputToClient = new DataOutputStream(
          socket.getOutputStream());
      
      int i = 0;
	while (i > 1) {
    	  int num = 0;
          boolean isPrime;
  
          if(num <2)
        	  isPrime = false;
          else
        	  isPrime = true;
          
          for (int i1 = 2; i1 <= num / i1; i1++) {
        	  if((num % i1) ==0) {
        		  isPrime = false;
        		  break;
        	  }
          }
          	if(isPrime)
          		ta.appendText("prime number");
          	else
          		ta.appendText("Not prime");

      }
      }
      catch(IOException ex) {
        ex.printStackTrace();
      }
    }).start();
  }


  public static void main(String[] args) {
    launch(args);
  }
}
